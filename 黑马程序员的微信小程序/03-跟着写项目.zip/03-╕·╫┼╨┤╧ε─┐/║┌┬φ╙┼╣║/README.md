<div>
  <h1>黑马优购</h1>
    <h2>介绍</h2>
  <p>黑马优购，微信小程序电商项目，适合各位拿来学习，可以动动发财的小手点个小star⭐</p>
  <p>接口路径：https://www.showdoc.com.cn/128719739414963/2513235043485226 </p>
</div>
  <h2>商品首页</h2>
  <img src='https://ae01.alicdn.com/kf/U16e0c95a9f1f4699ae7566a7e9aed1857.jpg'/>
  <h2>搜索</h2>
  <img src='https://ae01.alicdn.com/kf/Ua1890071ac0446a2b87059930574faa7g.jpg'/>
  <h2>购物车</h2>
  <img src='https://ae01.alicdn.com/kf/Ub5ed72d9750347ad8ea4d5b4f1529103q.jpg'/>
  <h2>购物车空</h2>
  <img src='https://ae01.alicdn.com/kf/Uf6648bcbf7c54e33abf701b641879b87r.jpg'/>
  <h2>分类</h2>
  <img src='https://ae01.alicdn.com/kf/U17307e7c84944a3d941ebeefe80bf06aH.jpg'/>
  <h2>支付</h2>
  <img src='https://ae01.alicdn.com/kf/Ud10b79552a234f48a647f18051b40134b.jpg'/>
  <h2>个人中心</h2>
  <img src='https://ae01.alicdn.com/kf/U8f179192704149288a1a2d0ae451fdf7e.jpg'/>
  <h2>商品列表</h2>
  <img src='https://ae01.alicdn.com/kf/U8fa4b39ffa1a4d45a4be7b478815ef47G.jpg'/>

 
